package com.example.mibancoapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class PaymentsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payments);


        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_menu:
                        Intent account = new Intent(String.valueOf(AccountActivity.class));
                        startActivity(account);
                        break;
                    case R.id.action_payments:
                        break;
                    case R.id.action_map:
                        Intent maps = new Intent(String.valueOf(MapActivity.class));
                        startActivity(maps);
                        break;
                    case R.id.action_more:
                        Intent more = new Intent(String.valueOf(MoreActivity.class));
                        startActivity(more);
                        break;
                }
                return true;
            }
        });


    }
}
